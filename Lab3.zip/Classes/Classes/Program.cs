﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Program
    {
        static void doWork()
        {
            Point origin = new Point();
            Point bottomRight = new Point(1366, 768);
            Point newLine = new Point(200, 100);
            Point anotherLine = new Point(500, 300);
            double distance = origin.DistanceTo(bottomRight);
            Line lineDistance = new Line(bottomRight, origin);
            Line secondLine = new Line(newLine, anotherLine);
            double secondDistance = secondLine.GetLength(secondLine);
            double distanceLength = lineDistance.GetLength(lineDistance);
            Console.WriteLine($"Distance is: {distance}");
            Console.WriteLine($"Number of Point objects: {Point.ObjectCount()}");
            Console.WriteLine($"Length is: {distanceLength}");
            Console.WriteLine($"Length is: {secondDistance}");
        }

        class Line
        {
            public Point p1, p2;

            public Line(Point p1, Point p2)
            {
                this.p1 = p1;
                this.p2 = p2;
            }

            
            public double GetLength(Line distance)
            {
                Point p1 = distance.p1;
                Point p2 = distance.p2;
                return p1.DistanceTo(p2);

            }
        }



        static void Main(string[] args)
        {
            try
            {
                doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
